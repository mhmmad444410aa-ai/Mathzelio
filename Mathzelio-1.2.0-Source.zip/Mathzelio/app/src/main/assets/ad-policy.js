/* Intentionally disabled for child-directed content. A future native integration must
   replace this adapter after documented Huawei approval, legal review, consent and
   non-personalised/category restrictions; never load ads from the game interface. */
window.MathzelioAds=Object.freeze({enabled:false,reason:'child-directed-unverified',request:()=>false});
