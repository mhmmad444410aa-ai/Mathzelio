(function(root){'use strict';
 const MODES=['numbers','count','add','subtract','multiply','divide','missing','sort','compare','puzzle'];
 const WORLDS=['numbersIsland','crystalCastle','rainbowValley','goldenDesert','frozenKingdom','cosmicMath'];
 const clamp=(v,a,b)=>Math.min(b,Math.max(a,v));
 function rng(seed){let x=(seed>>>0)||1;return ()=>{x^=x<<13;x^=x>>>17;x^=x<<5;return (x>>>0)/4294967296;};}
 function shuffle(a,r){a=a.slice();for(let i=a.length-1;i>0;i--){let j=Math.floor(r()*(i+1));[a[i],a[j]]=[a[j],a[i]];}return a;}
 function level(n){n=clamp(n,1,300);let world=Math.floor((n-1)/50),slot=(n-1)%50;
 const order=[['numbers','count','add','subtract','sort','compare','missing','puzzle','multiply','divide'],['count','add','subtract','missing','sort','compare','puzzle','numbers','multiply','divide'],['add','subtract','compare','missing','sort','puzzle','multiply','divide','count','numbers'],['multiply','divide','add','subtract','missing','puzzle','sort','compare','count','numbers'],['puzzle','missing','multiply','divide','sort','compare','add','subtract','count','numbers'],['compare','sort','puzzle','multiply','divide','missing','add','subtract','count','numbers']];
 return {id:n,world,mode:order[world][slot%10],difficulty:clamp(Math.floor(world/2)+1,1,3),rounds:3+Math.floor(world/2)};}
 function question(mode, difficulty, seed){const r=rng(seed),d=clamp(difficulty,1,3),ri=(a,b)=>a+Math.floor(r()*(b-a+1));let a,b,answer,prompt='',options=[],groups=[],kind='choice',seq=[],target=0,rule='';
 const max=[9,20,50][d-1];
 switch(mode){
 case 'numbers': a=ri(1,[10,20,50][d-1]);answer=a;prompt='recognise';kind='match';break;
 case 'count': a=ri(1,[8,12,18][d-1]);answer=a;prompt='countPrompt';groups=[a];break;
 case 'add': a=ri(1,max);b=ri(1,max);answer=a+b;prompt='solve';if(a+b<=20)groups=[a,b];break;
 case 'subtract': a=ri(2,max);b=ri(1,a);answer=a-b;prompt='solve';if(a<=18)groups=[a,b];break;
 case 'multiply': a=ri(2,[4,7,12][d-1]);b=ri(2,[5,9,12][d-1]);answer=a*b;prompt='solve';if(a*b<=20)groups=Array(a).fill(b);break;
 case 'divide': b=ri(2,[4,7,12][d-1]);answer=ri(1,[5,8,12][d-1]);a=b*answer;prompt='solve';if(a<=20)groups=Array(b).fill(answer);break;
 case 'missing': {let step=ri(1,d*3),start=ri(1,8),hole=ri(1,3);seq=Array.from({length:5},(_,i)=>start+i*step);answer=seq[hole];seq[hole]=null;prompt='complete';kind='drop';break;}
 case 'sort': {let s=new Set();while(s.size<4)s.add(ri(1,max));seq=[...s].sort((x,y)=>x-y);answer=seq.slice();options=shuffle(seq,r);if(options.every((v,i)=>v===seq[i]))[options[0],options[1]]=[options[1],options[0]];kind='sort';prompt='sortPrompt';break;}
 case 'compare': a=ri(1,max);b=r()<.23?a:ri(1,max);answer=a>b?'>':a<b?'<':'=';options=shuffle(['<','=','>'],r);kind='drop';prompt='comparePrompt';break;
 case 'puzzle': if(seed%2===0){target=ri(3,[8,12,18][d-1]);answer=target;kind='build';prompt='buildPrompt';}else{const pattern=d===1?[ri(1,5),ri(6,9)]:[ri(1,5),ri(6,9),ri(10,15)];seq=Array.from({length:5},(_,i)=>pattern[i%pattern.length]);answer=pattern[5%pattern.length];seq.push(null);kind='drop';prompt='patternPrompt';}break;
 default: throw Error('Unknown mode '+mode);
 }
 if(!options.length&&kind!=='build'){let set=new Set([answer]);while(set.size<3){let x=answer+ri(-Math.max(2,d*3),Math.max(2,d*3));if(x>=0)set.add(x);}options=shuffle([...set],r);}
 return {mode,difficulty:d,kind,prompt,a,b,answer,options,seq,groups,target};}
 function correct(q,value){return Array.isArray(q.answer)?Array.isArray(value)&&value.length===q.answer.length&&value.every((x,i)=>x===q.answer[i]):q.answer===value;}
 function adaptive(base, recent){if(recent.length<5)return base;const a=recent.slice(-8).filter(Boolean).length/Math.min(recent.length,8);return clamp(base+(a>=.875?1:a<.5?-1:0),1,3);}
 const api={MODES,WORLDS,level,question,correct,adaptive,shuffle,rng}; if(typeof module==='object'&&module.exports)module.exports=api;else root.Engine=api;
})(typeof globalThis!=='undefined'?globalThis:this);
