from playwright.sync_api import sync_playwright
from pathlib import Path
import threading, http.server, functools, tempfile, json
base=Path(__file__).resolve().parents[1]; assets=base/'app/src/main/assets'; dest=base/'store'/'browser-previews';dest.mkdir(exist_ok=True)
class Quiet(http.server.SimpleHTTPRequestHandler):
 def log_message(self,*args): pass
server=http.server.ThreadingHTTPServer(('127.0.0.1',0),functools.partial(Quiet,directory=str(assets)));threading.Thread(target=server.serve_forever,daemon=True).start()
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path='/usr/bin/chromium' if Path('/usr/bin/chromium').exists() else None,args=['--no-sandbox'])
 page=browser.new_page(viewport={'width':390,'height':780},device_scale_factor=2,has_touch=True,is_mobile=True)
 errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 page.goto((assets/'index.html').as_uri());page.wait_for_timeout(400)
 def click(s):page.locator(s).first.click()
 def act(a):click(f'[data-act="{a}"]')
 def shot(name):page.wait_for_timeout(350);page.screenshot(path=str(dest/(name+'.png')),animations='disabled')
 def solve():
  q=page.evaluate('run.question');kind=q['kind']
  if kind=='sort':
   for v in q['answer']:act('answer:'+str(q['options'].index(v)))
   act('check')
  elif kind=='build':
   for _ in range(q['target']):act('cube:1')
   act('check')
  else:act('answer:'+str(q['options'].index(q['answer'])))
  page.wait_for_timeout(770)
 shot('01-splash');act('home');shot('02-home');act('map');shot('03-worlds');act('world:0');act('level:1');shot('04-numbers');
 for _ in range(3):solve()
 assert page.evaluate('screen')=='win';assert page.evaluate('data.levels[1]')==3;shot('05-win');act('next');assert page.evaluate('run.id')==2;act('quit');act('map');act('home')
 for mode in page.evaluate('Engine.MODES'):
  act('practice:'+mode);act('startPractice:1')
  if mode=='add':shot('06-addition')
  if mode=='multiply':shot('07-multiplication')
  if mode=='missing':shot('08-missing')
  if mode=='sort':shot('09-sorting')
  for _ in range(4):solve()
  assert page.evaluate('screen')=='win',mode;act('home')
 act('daily');
 for _ in range(5):solve()
 assert page.evaluate('screen')=='win';assert page.evaluate('Object.keys(data.daily).length')==1;act('home');act('settings');act('lang:ar');assert page.locator('html').get_attribute('dir')=='rtl';act('home');shot('10-arabic-home');act('practice:add');act('startPractice:1');shot('11-arabic-game');act('gameSettings');act('lang:pt-BR');assert page.locator('html').get_attribute('lang')=='pt-BR';act('gate');page.locator('#pin').fill('5271');page.locator('#pin-form button').click();assert page.evaluate('screen')=='parent';shot('12-parent-report');act('privacy');assert page.evaluate('screen')=='privacy';act('parent');act('settings');act('gate');page.locator('#pin').fill('0000');page.locator('#pin-form button').click();assert page.evaluate('screen')=='gate';assert page.locator('#pin-error').inner_text();page.locator('#pin').fill('5271');page.locator('#pin-form button').click();assert page.evaluate('screen')=='parent';page.reload();assert page.evaluate('data.levels[1]')==3;assert page.evaluate('data.lang')=='pt-BR';assert page.evaluate('screen')=='splash'
 assert not errors, errors
 print('PASS: 10 practice modes, level completion and unlock, daily challenge, language/RTL, PIN denial/acceptance, progress persistence; no browser JS errors.')
 browser.close()
server.shutdown()
