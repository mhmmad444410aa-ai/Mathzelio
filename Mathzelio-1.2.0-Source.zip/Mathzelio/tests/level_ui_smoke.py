from pathlib import Path
from playwright.sync_api import sync_playwright
P=Path(__file__).resolve().parents[1];html=(P/'app/src/main/assets/index.html').read_text().replace('<body>','<body><script>const fixtureStore={};Object.defineProperty(window,"localStorage",{value:{getItem:k=>fixtureStore[k]??null,setItem:(k,v)=>fixtureStore[k]=String(v)}});</script>',1)
with sync_playwright() as pw:
 b=pw.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);p=b.new_page(viewport={'width':320,'height':640},has_touch=True,is_mobile=True);err=[];p.on('pageerror',lambda e:err.append(str(e)));p.set_content(html,wait_until='load')
 assert p.evaluate('screen')=='splash';assert p.locator('.start').evaluate('(x)=>getComputedStyle(x).backgroundImage')!='none'
 p.screenshot(path=str(P/'store/browser-previews/01-splash-small.png'),animations='disabled')
 p.locator('[data-act="home"]').first.click();p.screenshot(path=str(P/'store/browser-previews/02-home-small.png'),animations='disabled');assert p.evaluate('document.documentElement.scrollWidth')<=320
 res=p.evaluate('''() => { let passes=0; let worlds=new Set(), modes=new Set(); for(let i=1;i<=300;i++){begin('level',i); if(!document.querySelector('.board')||!document.querySelector('#drop-zone')||!document.querySelector('.choice-list button')||run.id!==i)throw Error('Level '+i); worlds.add(run.world);modes.add(run.mode);if(document.documentElement.scrollWidth>320)throw Error('Overflow '+i);passes++;}return [passes,worlds.size,modes.size];}''');assert res==[300,6,10],res
 # Force the construction branch, independent of random daily/practice seed.
 p.evaluate("begin('practice','puzzle',1);run.question=Engine.question('puzzle',1,222);drawGame();")
 assert p.evaluate('run.question.kind')=='build';x=p.locator('[data-build]').bounding_box();r=p.locator('#drop-zone').bounding_box();p.mouse.move(x['x']+x['width']/2,x['y']+x['height']/2);p.mouse.down();p.mouse.move(r['x']+r['width']/2,r['y']+r['height']/2,steps=10);p.mouse.up();assert p.evaluate('run.tower')==1
 assert not err,err;print('PASS: every one of 300 generated level screens, 6 worlds/10 modes, 320px width; construction drag verified. No browser JS errors.')
 b.close()
