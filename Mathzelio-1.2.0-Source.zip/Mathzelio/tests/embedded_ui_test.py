"""Test the exact bundled HTML in Chromium, using an isolated in-memory storage fixture."""
from pathlib import Path
from playwright.sync_api import sync_playwright
P=Path(__file__).resolve().parents[1]; html=(P/'app/src/main/assets/index.html').read_text(); D=P/'store/browser-previews';D.mkdir(exist_ok=True)
fixture="<script>const fixtureStore={};Object.defineProperty(window,'localStorage',{value:{getItem:k=>fixtureStore[k]??null,setItem:(k,v)=>fixtureStore[k]=String(v)}});</script>"
html=html.replace('<body>','<body>'+fixture,1)
with sync_playwright() as pw:
 b=pw.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);pg=b.new_page(viewport={'width':390,'height':780},device_scale_factor=1,has_touch=True,is_mobile=True);errors=[];pg.on('pageerror',lambda e:errors.append(str(e)));pg.set_content(html,wait_until='load');pg.wait_for_timeout(300)
 def act(a): pg.locator(f'[data-act="{a}"]').first.click(timeout=5000)
 def shot(n):pg.wait_for_timeout(120);pg.screenshot(path=str(D/(n+'.png')),animations='disabled')
 def drag(a):
  el=pg.locator(f'[data-act="{a}"]').first;el.scroll_into_view_if_needed();x=el.bounding_box();z=pg.locator('#drop-zone').bounding_box();assert x and z;pg.mouse.move(x['x']+x['width']/2,x['y']+x['height']/2);pg.mouse.down();pg.mouse.move(z['x']+z['width']/2,z['y']+z['height']/2,steps=8);pg.mouse.up()
 def solve(use_drag=False):
  q=pg.evaluate('run.question');k=q['kind'];choose=drag if use_drag else act;old=pg.evaluate('run.step')
  if k=='sort':
   for v in q['answer']:choose('answer:'+str(q['options'].index(v)))
   act('check')
  elif k=='build':
   for _ in range(q['target']):choose('cube:1')
   act('check')
  else:choose('answer:'+str(q['options'].index(q['answer'])))
  pg.wait_for_function('step=>screen === "win" || run.step>step',arg=old,timeout=4000)
 assert pg.evaluate('screen')=='splash',errors
 shot('01-splash');act('home');shot('02-home');act('map');shot('03-map');act('world:0');shot('04-levels');act('level:1');shot('05-numbers')
 q=pg.evaluate('run.question');act('answer:'+str(next(i for i,v in enumerate(q['options']) if v!=q['answer'])));assert pg.evaluate('run.message')=='tryAgain';assert pg.evaluate('run.step')==0
 for i in range(3):solve(i==0)
 assert pg.evaluate('screen')=='win';assert pg.evaluate('data.levels[1]')==3;shot('06-win');act('next');assert pg.evaluate('run.id')==2;act('quit');act('map');act('home')
 pg.evaluate('data.sound=false; save()')
 for mode in pg.evaluate('Engine.MODES'):
  act('practice:'+mode);act('startPractice:1');shot('skill-'+mode)
  if mode=='count':
   act('countCube:0');assert pg.evaluate('run.counted.length')==1;act('countCube:0');assert pg.evaluate('run.counted.length')==0
  for k in range(4):solve(k==0)
  assert pg.evaluate('screen')=='win',mode;act('home');print('PASS skill',mode,flush=True)
 act('daily')
 for _ in range(5):solve()
 assert pg.evaluate('screen')=='win';assert pg.evaluate('Object.keys(data.daily).length')==1;act('home');act('settings');act('lang:ar');assert pg.locator('html').get_attribute('dir')=='rtl';act('home');shot('07-arabic-home');act('practice:add');act('startPractice:1');shot('08-arabic-game');act('gameSettings');act('lang:pt-BR');assert pg.locator('html').get_attribute('lang')=='pt-BR';act('gate');pg.locator('#pin').fill('5271');pg.locator('#pin-form button').click();assert pg.evaluate('screen')=='parent';shot('09-parent');act('privacy');assert pg.evaluate('screen')=='privacy';act('parent');act('settings');act('gate');pg.locator('#pin').fill('0000');pg.locator('#pin-form button').click();assert pg.evaluate('screen')=='gate';assert pg.locator('#pin-error').inner_text();pg.locator('#pin').fill('5271');pg.locator('#pin-form button').click();assert pg.evaluate('screen')=='parent';assert pg.evaluate('JSON.parse(fixtureStore["mathzelio-v1"]).levels[1]')==3;assert pg.evaluate('JSON.parse(fixtureStore["mathzelio-v1"]).lang')=='pt-BR';assert not errors,errors
 print('PASS: 10 skills, feedback, drag, counting, level unlock, daily, 3 languages/RTL, PIN, saved JSON; no JS errors',flush=True)
 b.close()
