# Mathzelio 1.2.0 (build 4) — verification

## Work actually completed
- Original source and native test APK of 1.1.0 recovered; package name and launcher icon retained.
- Offline VTK geometry constructed and rendered for six distinct islands and six game backgrounds; five rounded game-block colours and a gold star rendered as separate sprites. Source generators: tools/render_art.py and tools/render_props.py (Python, VTK, NumPy, Pillow). No fal calls, charges, Blender or Godot.
- New UI styling: islands, selection cards, map, bevelled buttons, sets of game blocks, success star and breathing/floating motion; skills use different themed backgrounds. User-supplied logo unchanged.
- Preserved 300 generated levels, ten practice modes, six worlds, adaptive question difficulty, PIN, daily and local progress, and en-GB/ar/pt-BR. Offline package contains no ads or network permissions. The previous WebView startup fix is retained.

## Executed checks
- Node: 3,600 question checks; 300 levels, 10 modes, 6 worlds and adaptive difficulty, 108 keys per locale; passed.
- Chromium: 300 level screens at 320px, no horizontal overflow, construction drag passed.
- Chromium: all ten practice modes completed; incorrect feedback, drag-and-drop, count marking, level unlock, daily activity, three languages + RTL, local parent PIN and progress JSON checks passed. No page JS errors. Storage fixture rather than Android WebView persistence.
- APK: packaged from existing 1.1.0 native test host; version name/code patched to 1.2.0/4. Local cryptographic verification of APK Signature Scheme v2, SHA-256 chunk digest, RSA signature, certificate/public-key match, ZIP CRC, stored entry alignment, native DEX and original icon byte identity passed. Exact tested HTML payload matches APK. See store/*.txt.

## Limitations
- TEST APK is not a store release. New test signature differs from prior version; Android cannot install it over an old build signed with another key. Removing old app may erase local progress. Original signing key was not available. Newly generated test key is not included in the source ZIP.
- No Android SDK, Gradle or emulator available. Native host is repackaged rather than newly compiled; inherited minSdk 24 and targetSdk 32, unlike source project's API 23/36. No installation, touch-device, audio playback or real-device performance test. No Android apksigner; local v2 verifier is not its replacement.
- Graphics are actual rendered 3D models displayed as pre-rendered 2D assets; no runtime 3D engine, no exact reproduction of reference artwork, no individual 3D waterfall animation. Visual quality needs user approval.
- No new ad integration or remote publication. GitHub repository not accessible in this context. No promise of store approval.
