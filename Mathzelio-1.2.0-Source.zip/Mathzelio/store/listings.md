# App listing — Mathzelio

Package: com.mhmmad.mathzelio | 1.0.0 (1) | Ages 4–10

## English (UK)
Name: Mathzelio Math Games
Short description: Explore six colourful worlds and practise maths in playful offline challenges.
Long description:
Explore a floating world of numbers, castles, crystals and colourful islands. Mathzelio helps children practise maths at their own pace through ten learning activities: number recognition, counting, addition, subtraction, multiplication, division, missing numbers, sorting, comparison and logic puzzles. Discover 300 adventure levels, three challenge settings, visual hints, daily challenges and stars. Parents can review on-device progress in a PIN-protected area. English, Arabic and Brazilian Portuguese are available. Core activities work offline, without accounts, music, tracking or advertising in this version. Maths practice is educational and not a substitute for classroom teaching.

## العربية
الاسم: ماثزيليو ألعاب الرياضيات
الوصف القصير: اكتشف ستة عوالم ملونة وتعلم الرياضيات بتحديات ممتعة دون إنترنت.
الوصف الطويل:
انطلق في رحلة تعليمية وسط الجزر العائمة والقلاع والبلورات. تساعد ماثزيليو الأطفال على التدرب على الرياضيات وفق مستواهم، عبر عشرة أنشطة: تعلم الأرقام والعد والجمع والطرح والضرب والقسمة والرقم المفقود والترتيب والمقارنة والألغاز المنطقية. اكتشف ٣٠٠ مرحلة وستة عوالم وثلاث درجات صعوبة، مع تلميحات مرئية وتحديات يومية ونجوم. يستطيع الوالدان متابعة التقدم المحفوظ على الجهاز من منطقة محمية برمز. تدعم اللعبة الإنجليزية والعربية والبرتغالية البرازيلية. تعمل الأنشطة الأساسية دون إنترنت، ولا تتطلب حسابات أو إعلانات أو تتبعاً أو موسيقى في هذا الإصدار. اللعبة وسيلة تدريب تعليمية مساندة.

## Português (Brasil)
Nome: Mathzelio Jogos de Matemática
Descrição curta: Explore seis mundos e pratique matemática em desafios offline divertidos.
Descrição longa:
Explore ilhas flutuantes, castelos e cristais em uma aventura educativa. Mathzelio oferece dez atividades para praticar matemática no próprio ritmo: números, contagem, adição, subtração, multiplicação, divisão, números ausentes, ordenação, comparação e desafios de lógica. São 300 fases, seis mundos, três níveis de dificuldade, dicas visuais, desafios diários e estrelas. Os responsáveis podem conferir o progresso local em uma área protegida por PIN. Disponível em inglês, árabe e português do Brasil. As atividades principais funcionam offline, sem contas, rastreamento, anúncios ou música nesta versão. A prática complementa o aprendizado escolar.

ASO keywords are candidate terms only; no verified keyword volumes or brand clearance are claimed.
