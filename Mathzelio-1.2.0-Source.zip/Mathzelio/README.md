# Mathzelio Math Games
Android package `com.mhmmad.mathzelio`, 1.2.0 / 4.

## Implementation
Native Java Android Activity hosting a fully local HTML/CSS/JS game. No third-party runtime SDK or native libraries. Android System WebView is required (API 23+; modern WebView recommended). English UK default, Arabic RTL and Brazilian Portuguese. Reference artwork supplied by the project owner is used in the app; visual game elements are composed and interactive rather than a static screenshot. Six worlds now feature custom offline VTK-rendered three-dimensional models (floating islands, castles, crystals, pyramids, planet and blocks) composited as WebP sprites and scenes, and CSS motion overlays. This is a 2.5D presentation of true pre-rendered 3D geometry, not a live 3D engine. Button surfaces are CSS; game cubes and stars are 3D-rendered assets. The original launcher icon is unchanged. The offline web entry is self-contained to prevent missing-resource failures. The 300 levels are deterministic generated activities, not individually hand-authored. Progress is stored locally; clearing app data deletes progress. Local parent PIN is not strong authentication. No ads or network permissions. No external transmission.

## Build
Create a public GitHub repository and upload the CONTENTS of this directory, including `.github/workflows/release.yml`. GitHub Actions builds the Release configuration when pushed to main or manually dispatched. Without signing secrets it builds unsigned for verification only; it is not installable. With the permanent signing key and secrets, it builds and checks signed APK + AAB. Keep the signing key securely backed up offline. Do not generate a different key for updates or commit keys.

Expected secrets (GitHub Settings > Secrets and variables > Actions):
- `ANDROID_KEYSTORE_BASE64` — base64 encoding of permanent JKS/PKCS12 signing store.
- `ANDROID_STORE_PASSWORD`
- `ANDROID_KEY_ALIAS`
- `ANDROID_KEY_PASSWORD`

If this is the first-ever release and no signing key exists, create one once using Android Studio Generate Signed Bundle/APK or JDK keytool in a trusted environment and back it up privately. Never post it publicly.

The signed artifact appears in the workflow's Artifacts section, with `certificate.txt` including SHA-256. No permanent direct APK URL is created by this workflow. Local build with JDK 17, Android SDK 36, Gradle 8.11.1: `gradle assembleRelease` (unsigned if no signing variables).

## Testing
`python3 tools/pack.py` regenerates the self-contained WebView entry after editing CSS or JS. `node tests/engine.test.js` validates generated questions. `python tests/embedded_ui_test.py` and `python tests/level_ui_smoke.py` require Playwright and Chromium; these explicitly exercise the bundled content in a browser using a storage fixture, not in Android. See QA.md. The separately delivered TEST APK repackages the previous test APK native host and is signed with a different temporary key; it has min API 24 and target API 32, not the Gradle project target API 36. Do not publish the test APK. The original private signing key was not available.

## Ads and release policy
Ads are intentionally absent (no SDK and no ad calls). Do not add them until Huawei confirms the child-directed implementation, nonpersonalised ads, permitted placements, consent and practical category controls for intended regions. See https://developer.huawei.com/consumer/en/doc/monetize/policy4-0000001146675575 and https://developer.huawei.com/consumer/en/doc/app/50104-04/. Store acceptance is not guaranteed. Verify rights to supplied artwork, trademark/name availability, real store screenshots on Android and age rating. Host the finalized privacy policy at a publicly accessible HTTPS URL and add the verified support contact. Browser screenshots and actual browser testing records are supplied separately; Android device screenshots and installation testing are still pending.
