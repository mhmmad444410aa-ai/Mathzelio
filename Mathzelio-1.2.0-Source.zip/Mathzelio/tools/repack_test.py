"""Repack only an existing TEST APK native host. Not a substitute for Gradle release.
Requires cryptography. A separate PEM testing key can be supplied for repeat test updates.
Never check signing private keys into Git.
"""
import argparse, datetime, hashlib, io, struct, zipfile
from pathlib import Path
from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import rsa, padding
from cryptography.x509.oid import NameOID
u32=lambda a:struct.pack('<I',a);u64=lambda a:struct.pack('<Q',a);lp=lambda b:u32(len(b))+b
get32=lambda b,o:struct.unpack_from('<I',b,o)[0];get64=lambda b,o:struct.unpack_from('<Q',b,o)[0]
MAGIC=b'APK Sig Block 42'; ALG=0x0103; BLOCKID=0x7109871a
sha=lambda b:hashlib.sha256(b).digest()
def eocd(b):
 o=b.rfind(b'PK\x05\x06');assert o>=0 and o+22+struct.unpack_from('<H',b,o+20)[0]==len(b);return o,get32(b,o+16)
def digest(sections):
 chunks=[sha(b'\xa5'+u32(len(part[i:i+1048576]))+part[i:i+1048576]) for part in sections for i in range(0,len(part),1048576)]
 return sha(b'\x5a'+u32(len(chunks))+b''.join(chunks))
def getlp(b,o):
 n=get32(b,o);assert o+4+n<=len(b);return b[o+4:o+4+n],o+4+n
def verify(raw):
 e,cd=eocd(raw);assert raw[cd-16:cd]==MAGIC;size=get64(raw,cd-24);start=cd-size-8;assert get64(raw,start)==size;pos=start+8;val=None
 while pos<cd-24:
  l=get64(raw,pos);id=get32(raw,pos+8)
  if id==BLOCKID:val=raw[pos+12:pos+8+l]
  pos+=8+l
 assert val is not None
 allsigners,o=getlp(val,0);assert o==len(val);signer,o=getlp(allsigners,0);assert o==len(allsigners)
 sd,o=getlp(signer,0);sigs,o=getlp(signer,o);pub,o=getlp(signer,o);assert o==len(signer)
 sigrec,o=getlp(sigs,0);assert get32(sigrec,0)==ALG;signature,_=getlp(sigrec,4)
 digs,o=getlp(sd,0);certs,o=getlp(sd,o);attrs,o=getlp(sd,o)
 # Older signed host can include reserved trailing signed fields; signature still covers all sd.
 cert,_=getlp(certs,0);dr,_=getlp(digs,0);assert get32(dr,0)==ALG;d,_=getlp(dr,4)
 adj=bytearray(raw[e:]);struct.pack_into('<I',adj,16,start);assert d==digest([raw[:start],raw[cd:e],bytes(adj)]),'APK content digest mismatch'
 certobj=x509.load_der_x509_certificate(cert);pubkey=serialization.load_der_public_key(pub);assert certobj.public_key().public_bytes(serialization.Encoding.DER,serialization.PublicFormat.SubjectPublicKeyInfo)==pub
 pubkey.verify(signature,sd,padding.PKCS1v15(),hashes.SHA256());return hashlib.sha256(cert).hexdigest()
def patch_manifest(m):
 b=bytearray(m);names=[];off=8;got=[]
 while off<len(b):
  t,h,s=struct.unpack_from('<HHI',b,off);assert s>=8
  if t==1:
   count,_,flags,start,_=struct.unpack_from('<IIIII',b,off+8);assert flags&256
   for i in range(count):
    p=off+start+get32(b,off+h+i*4);n=b[p+1];v=b[p+2:p+2+n].decode();names.append(v)
    if v=='1.1.0':b[p+2:p+2+n]=b'1.2.0';got.append('name')
  if t==0x102:
   _,name,ao,asz,ac,*_=struct.unpack_from('<II6H',b,off+16)
   if names[name]=='manifest':
    for j in range(ac):
     p=off+16+ao+asz*j;at=get32(b,p+4)
     if names[at]=='versionCode':assert get32(b,p+16)==3;struct.pack_into('<I',b,p+16,4);got.append('code')
  off+=s
 assert sorted(got)==['code','name'];return bytes(b)
def pack(host,html):
 out=io.BytesIO()
 with zipfile.ZipFile(host) as old,zipfile.ZipFile(out,'w') as z:
  for entry in old.infolist():
   n=entry.filename
   if n.startswith('META-INF/'):continue
   v=old.read(n);info=zipfile.ZipInfo(n);info.compress_type=entry.compress_type
   if n=='AndroidManifest.xml':v=patch_manifest(v)
   if n=='assets/index.html':v=html
   if info.compress_type==zipfile.ZIP_STORED:
    # ZIP local extra alignment; valid extra header with padding.
    pad=(-(out.tell()+30+len(n.encode())+4))%4;info.extra=struct.pack('<HH',0xd935,pad)+bytes(pad)
   z.writestr(info,v)
 return out.getvalue()
def sign(raw,key,cert):
 e,cd=eocd(raw);dig=digest([raw[:cd],raw[cd:e],raw[e:]])
 der=cert.public_bytes(serialization.Encoding.DER);pub=key.public_key().public_bytes(serialization.Encoding.DER,serialization.PublicFormat.SubjectPublicKeyInfo)
 sd=lp(lp(u32(ALG)+lp(dig)))+lp(lp(der))+lp(b'');sig=key.sign(sd,padding.PKCS1v15(),hashes.SHA256());signer=lp(sd)+lp(lp(u32(ALG)+lp(sig)))+lp(pub);value=lp(lp(signer));pair=u64(4+len(value))+u32(BLOCKID)+value;size=len(pair)+24;blk=u64(size)+pair+u64(size)+MAGIC
 adj=bytearray(raw[e:]);struct.pack_into('<I',adj,16,cd+len(blk));return raw[:cd]+blk+raw[cd:e]+bytes(adj)
if __name__=='__main__':
 a=argparse.ArgumentParser();a.add_argument('host',type=Path);a.add_argument('html',type=Path);a.add_argument('output',type=Path);a.add_argument('--key',type=Path,required=True);a.add_argument('--cert',type=Path,required=True);args=a.parse_args()
 old=args.host.read_bytes();print('Input signature verified:',verify(old))
 if args.key.exists() and args.cert.exists():
  key=serialization.load_pem_private_key(args.key.read_bytes(),None);cert=x509.load_pem_x509_certificate(args.cert.read_bytes())
 elif not args.key.exists() and not args.cert.exists():
  key=rsa.generate_private_key(public_exponent=65537,key_size=2048);name=x509.Name([x509.NameAttribute(NameOID.COMMON_NAME,'Mathzelio local TEST only')]);now=datetime.datetime.now(datetime.timezone.utc);cert=x509.CertificateBuilder().subject_name(name).issuer_name(name).public_key(key.public_key()).serial_number(x509.random_serial_number()).not_valid_before(now-datetime.timedelta(days=1)).not_valid_after(now+datetime.timedelta(days=3650)).sign(key,hashes.SHA256());args.key.write_bytes(key.private_bytes(serialization.Encoding.PEM,serialization.PrivateFormat.PKCS8,serialization.NoEncryption()));args.key.chmod(0o600);args.cert.write_bytes(cert.public_bytes(serialization.Encoding.PEM))
 else:raise ValueError('Both existing test key and certificate must be present together')
 raw=sign(pack(args.host,args.html.read_bytes()),key,cert);print('New signature verified:',verify(raw));args.output.write_bytes(raw)
 with zipfile.ZipFile(args.host) as a,zipfile.ZipFile(args.output) as b:
  assert b.testzip() is None;assert a.read('classes.dex')==b.read('classes.dex');assert a.read('res/drawable/icon.png')==b.read('res/drawable/icon.png');assert b.read('assets/index.html')==args.html.read_bytes();assert b'1.2.0' in b.read('AndroidManifest.xml')
  for f in b.infolist():
   if f.compress_type==zipfile.ZIP_STORED:
    p=f.header_offset;fn,ex=struct.unpack_from('<HH',raw,p+26);assert (p+30+fn+ex)%4==0,f.filename
 print('ZIP CRC, stored entry alignment, DEX and launcher icon byte identity, payload identity: PASS');print('APK sha256:',hashlib.sha256(raw).hexdigest());print('APK size:',len(raw))
