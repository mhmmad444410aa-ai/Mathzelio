import vtk, math, random, numpy as np
from vtk.util.numpy_support import vtk_to_numpy
from PIL import Image, ImageDraw, ImageFilter
from pathlib import Path
P=Path(__file__).resolve().parents[1]/'app/src/main/assets'
def rgb(c):return tuple(int(c[i:i+2],16)/255 for i in (0,2,4))
class Stage:
 def __init__(self,size=(1000,1000)):
  self.r=vtk.vtkRenderer();self.r.SetBackgroundAlpha(0);self.r.SetUseFXAA(True)
  self.w=vtk.vtkRenderWindow();self.w.SetOffScreenRendering(1);self.w.SetAlphaBitPlanes(1);self.w.SetMultiSamples(0);self.w.SetSize(*size);self.w.AddRenderer(self.r)
  for pos,col,intensity in [((-6,9,8),'fff3dd',1.0),((7,5,-3),'b6d8ff',.65),((1,-1,10),'e2c5ff',.24)]:
   l=vtk.vtkLight();l.SetLightTypeToSceneLight();l.SetPosition(*pos);l.SetFocalPoint(0,0,0);l.SetColor(*rgb(col));l.SetIntensity(intensity);self.r.AddLight(l)
 def actor(self,s,col,pos=(0,0,0),scale=(1,1,1),rot=(0,0,0)):
  m=vtk.vtkPolyDataMapper();m.SetInputConnection(s.GetOutputPort()) if hasattr(s,'GetOutputPort') else m.SetInputData(s)
  a=vtk.vtkActor();a.SetMapper(m);a.SetPosition(*pos);a.SetScale(*scale);a.SetOrientation(*rot);p=a.GetProperty();p.SetColor(*rgb(col));p.SetAmbient(.28);p.SetDiffuse(.75);p.SetSpecular(.32);p.SetSpecularPower(30);self.r.AddActor(a);return a
 def sphere(self,pos,scale,col):
  s=vtk.vtkSphereSource();s.SetThetaResolution(28);s.SetPhiResolution(20);s.SetRadius(1);return self.actor(s,col,pos,scale)
 def cyl(self,pos,r,h,col,n=40,scale=(1,1,1)):
  s=vtk.vtkCylinderSource();s.SetResolution(n);s.SetRadius(r);s.SetHeight(h);return self.actor(s,col,pos,scale)
 def cone(self,pos,r,h,col,n=36):
  s=vtk.vtkConeSource();s.SetResolution(n);s.SetRadius(r);s.SetHeight(h);return self.actor(s,col,pos,rot=(0,0,90))
 def box(self,pos,scale,col,rot=(0,0,0)):
  return self.actor(vtk.vtkCubeSource(),col,pos,scale,rot)
 def mesh(self,verts,faces,col,colors=None):
  pts=vtk.vtkPoints();[pts.InsertNextPoint(*p) for p in verts];cells=vtk.vtkCellArray()
  for face in faces:
   cells.InsertNextCell(len(face));[cells.InsertCellPoint(i) for i in face]
  poly=vtk.vtkPolyData();poly.SetPoints(pts);poly.SetPolys(cells);a=self.actor(poly,col);a.GetProperty().SetInterpolationToFlat()
  if colors:
   arr=vtk.vtkUnsignedCharArray();arr.SetNumberOfComponents(3)
   for c in colors:arr.InsertNextTuple3(*(int(c[i:i+2],16) for i in (0,2,4)))
   poly.GetCellData().SetScalars(arr);a.GetMapper().SetScalarModeToUseCellData();a.GetMapper().ScalarVisibilityOn()
  return a
 def render(self,zoom=4.15):
  c=self.r.GetActiveCamera();c.SetPosition(5,4.6,11);c.SetFocalPoint(0,.25,0);c.SetViewUp(0,1,0);c.ParallelProjectionOn();c.SetParallelScale(zoom);self.r.ResetCameraClippingRange();self.w.Render();f=vtk.vtkWindowToImageFilter();f.SetInput(self.w);f.SetInputBufferTypeToRGBA();f.ReadFrontBufferOff();f.Update();o=f.GetOutput();x,y,_=o.GetDimensions();d=vtk_to_numpy(o.GetPointData().GetScalars()).reshape(y,x,4)[::-1].copy();self.w.Finalize();return Image.fromarray(d,'RGBA')
PAL=[('83c82f','539a22','ad768f','774373','9e52df','ffca40','f1cdbb','43d6fa'),('65bf56','328751','826cbd','493a87','be70ed','ffcb60','dbc7f2','5cf1ed'),('93ce42','489d31','ba6ea4','88447d','ee6f9f','ffce42','ffcbb5','54d8ff'),('dcb660','ab7138','cb8064','874759','2cbdbe','ffda6a','ffe1a4','33d9e9'),('cceffc','7bc7db','9bb5db','5c7da7','508fe7','ffdf8d','edfaff','6df7ff'),('777cd0','4447a3','655ca7','39356e','e169d5','ffcb5f','bfbafb','60d8fa')]
def rock(s,p):
 top,side,r1,r2,*_=p;n=14;vs=[]
 for r,y in [(3.05,-.05),(2.82,-.42),(2.04,-1.37),(.9,-2.3),(.18,-2.56)]:
  for j in range(n):
   a=j*math.tau/n;w=1+random.uniform(-.075,.075);vs.append((r*w*math.cos(a),y+random.uniform(-.07,.07),r*.82*w*math.sin(a)))
 fs=[];cs=[]
 for k in range(4):
  for j in range(n):
   a=k*n+j;b=k*n+(j+1)%n;c=b+n;d=a+n
   for f in [(a,b,c),(a,c,d)]:fs.append(f);cs.append(random.choice([side,top] if k==0 else [r1,r2,r1]))
 fs.append(tuple(range(n-1,-1,-1)));cs.append(top);s.mesh(vs,fs,r1,cs);s.cyl((0,-.05,0),2.83,.23,top,48,(1,1,.82))
 for j in range(25):
  a=j*math.tau/25;s.sphere((2.8*math.cos(a),-.05,2.23*math.sin(a)),(.44,.17,.38),random.choice([top,top,side]))
 for j in range(17):
  a=random.uniform(0,math.tau);r=random.uniform(2.25,2.65);s.sphere((r*math.cos(a),.13,r*.8*math.sin(a)),(.21,.12,.16),random.choice(['beb2c4','e1c1ba',side]))
def tree(s,x,z,sz,top,side):
 s.cyl((x,.35*sz,z),.07*sz,.73*sz,'946b4d',12)
 for dx,y,dz,r in [(0,.85,0,.38),(-.22,.68,.04,.30),(.24,.72,-.02,.32),(0,1.14,-.04,.30),(.02,.76,.23,.24)]:s.sphere((x+dx*sz,y*sz,z+dz*sz),(r*sz,r*sz*.91,r*sz),random.choice([top,top,side]))
def crystal(s,x,z,h,col):
 n=5;vs=[];r=h*.27
 for y,rr in [(0,.7*r),(h*.22,r),(h*.7,r*.84)]:
  for j in range(n):a=j*math.tau/n+.24;vs.append((x+rr*math.cos(a),y,z+rr*math.sin(a)))
 vs.append((x+r*.12,h,z));fs=[]
 for k in range(2):
  for j in range(n):fs.append((k*n+j,k*n+(j+1)%n,(k+1)*n+(j+1)%n,(k+1)*n+j))
 for j in range(n):fs.append((2*n+j,2*n+(j+1)%n,3*n))
 c0=np.array(rgb(col))*255;cs=[''.join(f'{int(v):02x}' for v in np.clip(c0*random.uniform(.72,1.23)+random.uniform(0,22),0,255)) for _ in fs];s.mesh(vs,fs,col,cs)
def turret(s,x,z,r,h,roof,trim,wall):
 s.cyl((x,h/2,z),r,h,wall);s.cyl((x,.12,z),r*1.1,.22,trim);s.cyl((x,h-.02,z),r*1.14,.18,trim)
 for i in range(1,4):s.cyl((x,i*h/4,z),r*1.008,.027,'d8adad')
 s.box((x,h*.62,z+r*.97),(r*.43,h*.27,.045),'eca72b');s.sphere((x,h*.755,z+r*.97),(r*.22,r*.26,.06),'ffde59');s.box((x,h*.63,z+r+.02),(.055,h*.26,.045),trim)
 s.cone((x,h+r*.96,z),r*1.22,r*1.9,roof)
 for i in (1,2,3):s.cyl((x,h+r*.37*i,z),r*1.22*(1-i*.19),.045,roof)
 s.sphere((x,h+r*1.97,z),(.10,.11,.10),trim)
def castle(s,p):
 _,_,_,_,roof,trim,wall,_=p;s.box((0,.62,-.33),(1.97,1.24,1.43),wall);s.box((0,1.28,-.33),(2.05,.18,1.5),trim)
 for i in range(7):s.box((-.9+i*.3,1.49,.38),(.18,.28,.24),wall)
 turret(s,0,-.65,.7,2.02,roof,trim,wall);turret(s,-1.12,.13,.47,1.37,roof,trim,wall);turret(s,1.12,.13,.47,1.37,roof,trim,wall)
 s.box((0,.42,.42),(.9,.84,.12),'f7ca65');s.sphere((0,.83,.44),(.45,.40,.10),'f7ca65');s.box((0,.38,.5),(.65,.75,.12),'c87825');s.sphere((0,.73,.5),(.325,.31,.075),'c87825');s.box((0,.43,.57),(.045,.78,.03),'a76525');s.sphere((.16,.36,.6),(.05,.05,.035),'ffe27a')
 for i in range(5):s.box((0,.05+i*.06,1.75-i*.24),(1.10-i*.07,.12,.38),'eed1bc')
 s.cyl((0,3.67,-.65),.026,.63,'ffc953');s.mesh([(0,3.96,-.65),(.55,3.90,-.65),(.8,3.72,-.65),(.42,3.62,-.65),(0,3.68,-.65)],[(0,1,2,3,4)],'f94570')
def water(s,p):
 c=p[-1];s.sphere((1.52,.05,1.53),(.69,.08,.55),c);vs=[]
 for k in range(10):
  y=.05-k*.29;z=1.88+min(k,2)*.22+max(0,k-2)*.045;w=.36-.011*k;vs.extend([(1.52-w,y,z),(1.52+w,y,z+.02)])
 s.mesh(vs,[(2*i,2*i+1,2*i+3,2*i+2) for i in range(9)],c)
 for i in range(5):s.box((1.25+i*.12,-1.08,2.35),(.035,2.04,.025),'a8f4ff',(4,0,0))
 for i in range(8):s.sphere((1.12+i*.115,-2.47,2.55),(.14,.13,.10),'cef8ff')
def island(i):
 p=PAL[i];s=Stage();random.seed(100+i);rock(s,p)
 if i in [0,4]:castle(s,p)
 elif i==1:
  s.cyl((0,.13,-.3),1.53,.15,p[5],48)
  for x,z,h in [(0,-.5,2.9),(-.88,-.2,1.72),(.95,-.4,2.05),(-.35,.42,1.13),(.72,.32,1.41)]:crystal(s,x,z,h,p[4])
 elif i==2:
  for j in range(5):
   a=j*math.tau/5;x=math.cos(a)*1.1;z=math.sin(a)*.75-.25;s.box((x,.55+j*.09,z),(.69,1.1+j*.18,.69),['ff6688','50c4fe','ffce37','a067ef','23cbb5'][j],(0,20*j,0));s.sphere((x,1.2+j*.19,z),(.15,.15,.15),p[5])
 elif i==3:
  for x,z,h in [(-1,-.7,2.2),(.7,-.5,2.8),(.4,.7,1.35)]:s.cone((x,h/2,z),h*.65,h,'f8c56e',4);s.cyl((x,.12,z),h*.65,.19,'dc9856',4)
 else:
  s.cyl((0,.28,-.45),1.28,.45,'ad93ee');s.sphere((0,1.55,-.45),(1.10,1.08,1.10),'c27aee');t=vtk.vtkParametricTorus();t.SetRingRadius(1.4);t.SetCrossSectionRadius(.085);sf=vtk.vtkParametricFunctionSource();sf.SetParametricFunction(t);sf.SetUResolution(64);sf.SetVResolution(18);s.actor(sf,'ffcf69',(0,1.55,-.45),rot=(64,12,22))
 for x,z,sz in [(-2.1,-.5,.82),(2,-.6,.93),(-1.67,1.25,.82),(.23,-1.9,1),(2.1,.48,.7),(-2.2,.4,.55)]:tree(s,x,z,sz,'bfefff' if i==4 else ('8b87eb' if i==5 else '8cd53e'),'78bada' if i==4 else ('4d52b7' if i==5 else '3b9f48'))
 for x,z,h in [(-1,1.65,.73),(-1.36,1.48,.55),(2.15,1,.68)]:crystal(s,x,z,h,p[4])
 water(s,p);im=s.render();im=im.crop(im.getbbox());im.save(P/f'hero-{i}.webp',quality=94,method=4);return im
def cloud_layer(w,h,seed):
 r=random.Random(seed);im=Image.new('RGBA',(w,h));d=ImageDraw.Draw(im)
 for k in range(30):
  x=r.randrange(-220,w+220);y=r.randrange(0,h);sz=r.randrange(45,150)
  if 250<x<w-250 and 260<y<h-280:continue
  for j in range(5):
   xx=x+(j-2)*sz*.34;yy=y+r.randrange(-25,25);rr=sz*r.uniform(.4,.75);d.ellipse((xx-rr,yy-rr*.55,xx+rr,yy+rr*.55),fill=(249,247,255,r.randrange(45,125)))
 return im.filter(ImageFilter.GaussianBlur(9))
def background(i,hero):
 w,h=1080,1920;sky=[('136bd8','42c8fc','d1f8ff'),('513ac5','9673ed','e7c9ff'),('4584d9','e99cd7','ffe6b7'),('e98837','ffc05b','fff0b3'),('337fce','80d8f8','e7fcff'),('25256f','6255c6','b5a9f6')][i];a,b,c=map(lambda x:np.array(rgb(x)),sky);mix=np.array([(a*(1-t*2)+b*t*2 if t<.5 else b*(2-2*t)+c*(2*t-1)) for t in np.linspace(0,1,h)]);arr=np.broadcast_to((mix*255).astype('uint8')[:,None,:],(h,w,3)).copy();im=Image.fromarray(arr).convert('RGBA');im.alpha_composite(cloud_layer(w,h,30+i))
 def paste(x,y,ww,opacity=255):
  sp=hero.resize((ww,round(hero.height*ww/hero.width)),Image.Resampling.LANCZOS);sp.putalpha(sp.getchannel('A').point(lambda a:a*opacity//255));im.alpha_composite(sp,(x,y))
 paste(-180,90,480,170);paste(790,290,410,150);paste(-230,790,470,190);paste(855,930,385,200);paste(70,1480,950);im.alpha_composite(cloud_layer(w,h,80+i));im.convert('RGB').save(P/f'premium-scene-{i}.webp',quality=92,method=4)
if __name__=='__main__':
 for i in range(6):
  print('Rendering world',i,flush=True);h=island(i);background(i,h)
 print('DONE')
