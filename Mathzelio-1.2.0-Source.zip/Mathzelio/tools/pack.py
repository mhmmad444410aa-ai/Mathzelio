#!/usr/bin/env python3
"""Create a fully self-contained WebView entry. No network or late file script loading."""
from pathlib import Path
import base64, re, json
P=Path(__file__).resolve().parents[1]/'app/src/main/assets'
def uri(name):
 p=P/name; mime={'webp':'image/webp','png':'image/png','svg':'image/svg+xml'}[p.suffix[1:]]
 return 'data:'+mime+';base64,'+base64.b64encode(p.read_bytes()).decode()
css=(P/'style.css').read_text()
css=re.sub(r"url\(['\"]?([^)'\"]+)['\"]?\)", lambda m:'url("'+uri(m[1])+'")' if (P/m[1]).is_file() else m[0],css)
art={name:uri(name) for name in ['logo.webp']+[f'hero-{i}.webp' for i in range(6)]}
js=(P/'game.js').read_text()
js=re.sub(r'src="(logo\.webp|hero-0\.webp)"',lambda m:'src="${ART['+repr(m[1])+']}"',js)
js=js.replace('src="hero-${i}.webp"','src="${ART[\'hero-\'+i+\'.webp\']}"')
script='const ART='+json.dumps(art,separators=(',',':'))+';\n'+'\n'.join((P/f).read_text() for f in ['engine.js','translations.js','ad-policy.js'])+'\n'+js
# CSP permits only bundled inline script/style and image data; native host blocks network.
html='''<!doctype html><html lang="en-GB" dir="ltr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover"><meta http-equiv="Content-Security-Policy" content="default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; img-src data:; connect-src 'none'; object-src 'none'; base-uri 'none'"><title>Mathzelio Math Games</title><style>'''+css+'''</style></head><body><div id="app"><div style="min-height:100vh;background:#5837a5;display:grid;place-items:center;color:white;text-align:center;padding:25px"><div><img style="width:min(85vw,300px)" alt="Mathzelio" src="'''+art['logo.webp']+'''"><p>Mathzelio • Loading…</p><p id="startup-error" style="font-size:14px;display:none">Please update Android System WebView and reopen the game.</p></div></div></div><script>window.addEventListener('error',function(){var e=document.getElementById('startup-error');if(e)e.style.display='block';});</script><script>'''+script.replace('</script','<\\/script')+'</script></body></html>'
(P/'index.html').write_text(html)
print('Packed',len(html),'characters')
