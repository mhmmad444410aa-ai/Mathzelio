from render_art import *
# Separate reusable game tokens created from 3D geometry, not emoji.
for name,col in [('red','ff5076'),('cyan','13c8c9'),('green','8ccf43'),('purple','a25df0'),('yellow','ffc436')]:
 s=Stage((320,320));source=vtk.vtkSuperquadricSource();source.SetPhiResolution(64);source.SetThetaResolution(64);source.SetPhiRoundness(.23);source.SetThetaRoundness(.23);source.SetSize(.82);source.SetToroidal(False);s.actor(source,col,(0,.25,0));im=s.render(.66);im=im.crop(im.getbbox());im.save(P/f'prop-{name}.webp',quality=95)
# bevelled golden star, from a closed solid
s=Stage((360,360));vs=[]
for z,scale in [(-.14,.86),(-.09,1),(.1,1),(.20,.82)]:
 for i in range(10):
  a=math.pi/2+i*math.pi/5;r=(.68 if i%2==0 else .33)*scale;vs.append((r*math.cos(a),.25+r*math.sin(a),z))
fs=[]
for j in range(3):
 for i in range(10):fs.append((j*10+i,j*10+(i+1)%10,(j+1)*10+(i+1)%10,(j+1)*10+i))
fs.append(tuple(range(30,40)));fs.append(tuple(range(9,-1,-1)));s.mesh(vs,fs,'ffbb21');im=s.render(.8);im.crop(im.getbbox()).save(P/'prop-star.webp',quality=96)
